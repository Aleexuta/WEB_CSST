Pentru tema de la curs folderul necesar este frontend. in fisierul js/main.js pentru a verifica functionalitatea fiecarui tip de cont pe linia 125 se pune 
*0 pt guest (nu apare orarul custom al fiecarui sportiv)
*1 pt cont normal (apare orarul custom ce va fi populat din baza de date)
*2 pt contul admin (apar butoanele de adaugare curs, articol iar numele sportivilor pot fi apelate)

cand guest apasa pe Profil va fi trimis pe pagina de login,
daca e conectat va aparea pagina profilului, cu functionalitatea de schimbare a parolei si retragerea de la cursuri.
adminul poate apela profilul celorlalti sportivi din sectiunea "sportivi", moment cand se deschide pagina de profil cu functionalitatea de "promovare la instructor".